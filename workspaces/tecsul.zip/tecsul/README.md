# Tecsul — Loja de Eletrodomésticos e Eletrônicos

Site moderno de e-commerce inspirado no layout do Carrefour, seguindo as diretrizes de design do **Emil Kowalski** (Design Engineering Skills) e **Taste Skill** (anti-slop).

## Princípios aplicados

- **Sem gradientes, sem glass, sem blobs, sem emojis**
- **Sombras apenas em interação** (hover/press) — nunca em repouso
- **Uma grid, margens apertadas** — espaçamento em múltiplos de 4px
- **Paleta restrita**: um ground (branco), um ink (azul-escuro), um accent (azul Tecsul #0057b8)
- **Tipografia**: 3 tamanhos hierárquicos, tracking negativo em títulos
- **Imagem dominante** no hero — uma grande vence várias pequenas
- **Animações com easing spring** (`cubic-bezier(0.22, 1, 0.36, 1)`)
- **Botões responsivos** com `scale(0.97)` no `:active`

## Estrutura

```
tecsul/
├── index.html   # Estrutura semântica
├── style.css    # Design system + componentes
├── script.js    # Catálogo, carrinho, busca, toast
└── README.md
```

## Funcionalidades

- Catálogo com 8 produtos reais (imagens validadas de varejistas brasileiros)
- Carrinho lateral (drawer) com animação spring
- Busca por nome, marca ou categoria
- Filtro por categoria via navegação
- Cálculo automático de desconto e parcelamento 12x
- Toast de feedback
- Totalmente responsivo (desktop, tablet, mobile)
- Acessibilidade: `aria-label`, `role="search"`, `aria-live="polite"` no toast

## Como usar

Abra `index.html` diretamente no navegador — não requer build ou servidor.

## Imagens

Todas as imagens são de produtos reais hospedadas em CDNs de varejistas brasileiros (MadeiraMadeira, Carrefour, Magalu, Americanas, Shopee, etc.) e foram validadas via `web_fetch`.
