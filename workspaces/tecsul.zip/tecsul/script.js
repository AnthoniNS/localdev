// ============================================
// Tecsul — Lógica da Loja
// ============================================

// Catálogo de produtos com imagens reais validadas
const products = [
  {
    id: 1,
    name: 'Geladeira Frost Free Duplex 400L Inox',
    brand: 'Electrolux',
    category: 'geladeiras',
    image: 'https://product-hub-prd.madeiramadeira.com.br/238282475/images/a6342e7c-2fc0-4c0e-bacb-4e80359801c0standardresolution.jpg',
    price: 3299.90,
    oldPrice: 4399.90,
    discount: 25
  },
  {
    id: 2,
    name: 'Fogão 5 Bocas Inox com Forno Elétrico',
    brand: 'Brastemp',
    category: 'cozinha',
    image: 'https://carrefourbr.vtexassets.com/arquivos/ids/6367143/MP04391639_Fogao-Brastemp-5-Bocas-Cor-Inox-Forno-Eletrico-Com-Conveccao-E-Meat-Control---BFS5CCR-220V_1_Zoom.jpg?v=637343113765670000',
    price: 2199.90,
    oldPrice: 2799.90,
    discount: 21
  },
  {
    id: 3,
    name: 'Micro-ondas 32L Inox com Grill',
    brand: 'Brastemp',
    category: 'cozinha',
    image: 'https://product-hub-prd.madeiramadeira.com.br/194010502/images/50a62983-bf1b-421d-9347-810c41d73e95e1b945c0standardresolution.jpg',
    price: 899.90,
    oldPrice: 1099.90,
    discount: 18
  },
  {
    id: 4,
    name: 'Air Fryer Jumbo Inox 7,2L',
    brand: 'Philco',
    category: 'cozinha',
    image: 'https://down-br.img.susercontent.com/file/br-11134207-7r98o-mailw7o5l5zj1a',
    price: 549.90,
    oldPrice: 699.90,
    discount: 21
  },
  {
    id: 5,
    name: 'Smart TV 50" Crystal UHD 4K',
    brand: 'Samsung',
    category: 'eletronicos',
    image: 'https://m.magazineluiza.com.br/a-static/420x420/smart-tv-50-polegadas-samsung-crystal-uhd-4k-50au7700-bivolt/magazineluiza/193441200/bcc0f75c9d510b7b3af0e2c4f04fc7a9.jpg',
    price: 2799.90,
    oldPrice: 3499.90,
    discount: 20
  },
  {
    id: 6,
    name: 'Ar Condicionado Split Inverter 12000 BTUs',
    brand: 'LG',
    category: 'eletronicos',
    image: 'https://americanas.vtexassets.com/arquivos/ids/33655938/Ar-Condicionado-Split-Inverter-12000-BTUs-LG-Dual-Voice--AI-Artcool-UV-Nano-Quente-e-Frio-S3-W12JAR7A-220V.jpg?v=638862939274630000',
    price: 2499.90,
    oldPrice: 3199.90,
    discount: 22
  },
  {
    id: 7,
    name: 'Máquina de Lavar 11kg Titanium',
    brand: 'Midea',
    category: 'lavanderia',
    image: 'https://product-hub-prd.madeiramadeira.com.br/288084712/images/9467e198-c05b-40ce-96e8-ec06e7cb2a65K01.MF200W110WBGK02Vitrine.jpg',
    price: 1899.90,
    oldPrice: 2399.90,
    discount: 21
  },
  {
    id: 8,
    name: 'Notebook Core i5 8GB SSD 256GB',
    brand: 'Dell',
    category: 'eletronicos',
    image: 'https://images.tcdn.com.br/img/img_prod/167552/notebook_profissional_dell_latitude_5490_tela_14_intel_core_i5_8a_geracao_8gb_ssd_256gb_15887_1_004f00b82ee40a501c941e3e22275993.png',
    price: 3499.90,
    oldPrice: 4299.90,
    discount: 19
  }
];

// Estado da aplicação
let cart = [];
let currentFilter = 'all';

// ============================================
// RENDERIZAÇÃO DE PRODUTOS
// ============================================

function renderProducts(filter = 'all', searchTerm = '') {
  const grid = document.getElementById('productGrid');
  
  let filteredProducts = products;
  
  if (filter !== 'all') {
    filteredProducts = filteredProducts.filter(p => p.category === filter);
  }
  
  if (searchTerm) {
    const term = searchTerm.toLowerCase();
    filteredProducts = filteredProducts.filter(p => 
      p.name.toLowerCase().includes(term) || 
      p.brand.toLowerCase().includes(term) ||
      p.category.toLowerCase().includes(term)
    );
  }
  
  if (filteredProducts.length === 0) {
    grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--ink-muted); padding: var(--s-12) 0;">Nenhum produto encontrado.</p>';
    return;
  }
  
  grid.innerHTML = filteredProducts.map(product => `
    <article class="product-card" data-id="${product.id}">
      <div class="product-image">
        ${product.discount ? `<span class="product-badge">-${product.discount}%</span>` : ''}
        <img src="${product.image}" alt="${product.name}" loading="lazy" />
      </div>
      <div class="product-body">
        <span class="product-brand">${product.brand}</span>
        <h3 class="product-name">${product.name}</h3>
        <div class="product-price">
          ${product.oldPrice ? `<div class="price-old">R$ ${formatPrice(product.oldPrice)}</div>` : ''}
          <div class="price-now">R$ ${formatPrice(product.price)}</div>
          <div class="price-installment">ou 12x de R$ ${formatPrice(product.price / 12)} sem juros</div>
        </div>
        <button class="btn add-cart" onclick="addToCart(${product.id})">
          Adicionar ao carrinho
        </button>
      </div>
    </article>
  `).join('');
}

// ============================================
// CARRINHO
// ============================================

function addToCart(productId) {
  const product = products.find(p => p.id === productId);
  if (!product) return;
  
  const existingItem = cart.find(item => item.id === productId);
  
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ ...product, quantity: 1 });
  }
  
  updateCartUI();
  showToast(`${product.name} adicionado ao carrinho`);
}

function removeFromCart(productId) {
  cart = cart.filter(item => item.id !== productId);
  updateCartUI();
}

function updateCartUI() {
  const cartCount = document.getElementById('cartCount');
  const cartTotal = document.getElementById('cartTotal');
  const drawerBody = document.getElementById('drawerBody');
  
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  // Atualiza contador
  cartCount.textContent = totalItems;
  if (totalItems > 0) {
    cartCount.classList.add('visible');
  } else {
    cartCount.classList.remove('visible');
  }
  
  // Atualiza total
  cartTotal.textContent = `R$ ${formatPrice(totalPrice)}`;
  
  // Atualiza lista de itens
  if (cart.length === 0) {
    drawerBody.innerHTML = '<p class="empty">Seu carrinho está vazio.</p>';
  } else {
    drawerBody.innerHTML = cart.map(item => `
      <div class="cart-item">
        <img src="${item.image}" alt="${item.name}" />
        <div class="cart-item-info">
          <div class="cart-item-name">${item.name}</div>
          <div class="cart-item-price">R$ ${formatPrice(item.price)} × ${item.quantity}</div>
        </div>
        <button class="cart-item-remove" onclick="removeFromCart(${item.id})">
          Remover
        </button>
      </div>
    `).join('');
  }
}

function openDrawer() {
  document.getElementById('drawer').classList.add('open');
  document.getElementById('drawerBackdrop').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeDrawer() {
  document.getElementById('drawer').classList.remove('open');
  document.getElementById('drawerBackdrop').classList.remove('open');
  document.body.style.overflow = '';
}

function checkout() {
  if (cart.length === 0) {
    showToast('Seu carrinho está vazio');
    return;
  }
  
  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  showToast(`Compra finalizada! Total: R$ ${formatPrice(total)}`);
  cart = [];
  updateCartUI();
  closeDrawer();
}

// ============================================
// BUSCA
// ============================================

function handleSearch(searchTerm) {
  renderProducts(currentFilter, searchTerm);
  document.getElementById('ofertas').scrollIntoView({ behavior: 'smooth' });
}

// ============================================
// NEWSLETTER
// ============================================

function subscribeNewsletter(email) {
  showToast(`Obrigado! Enviaremos ofertas para ${email}`);
  event.target.reset();
}

// ============================================
// TOAST
// ============================================

let toastTimeout;

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

// ============================================
// UTILITÁRIOS
// ============================================

function formatPrice(value) {
  return value.toFixed(2).replace('.', ',');
}

// ============================================
// NAVEGAÇÃO POR CATEGORIA
// ============================================

document.querySelectorAll('.primary-nav a, .category-card').forEach(link => {
  link.addEventListener('click', (e) => {
    const href = link.getAttribute('href');
    if (href && href.startsWith('#')) {
      const category = href.substring(1);
      
      if (category === 'ofertas' || category === 'categorias') {
        return;
      }
      
      e.preventDefault();
      currentFilter = category === 'all' ? 'all' : category;
      renderProducts(currentFilter);
      document.getElementById('ofertas').scrollIntoView({ behavior: 'smooth' });
    }
  });
});

// ============================================
// INICIALIZAÇÃO
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  // Renderiza produtos iniciais
  renderProducts();
  
  // Event listeners do carrinho
  document.getElementById('cartBtn').addEventListener('click', openDrawer);
  document.getElementById('closeDrawer').addEventListener('click', closeDrawer);
  document.getElementById('drawerBackdrop').addEventListener('click', closeDrawer);
  
  // Fecha drawer com ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeDrawer();
    }
  });
});
